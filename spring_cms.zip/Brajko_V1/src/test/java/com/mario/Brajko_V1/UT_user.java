package com.mario.Brajko_V1;

import java.util.List;

import javax.transaction.Transactional;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mario.Brajko_V1.model.Post;
import com.mario.Brajko_V1.model.User;
import com.mario.Brajko_V1.service.PostServiceImpl;
import com.mario.Brajko_V1.service.UserServiceImpl;


@RunWith(SpringRunner.class)
@SpringBootTest
public class UT_user {
	
	private static final Long USER_ID = 1L;
	private static final Long POST_ID = 1L;
	private static final User NEW_USER = new User("Mirka", "Mirkić", "mmirkic", "psadf", "user");
	private static final String USER_NAME_UPDATED = "Name_updated";
	private static final String USER_SURNAME_UPDATED = "Surname_updated";
	private static final String USER_USERNAME_UPDATED = "Username_updated";
	private static final String USER_PASSWORD_UPDATED = "Password_updated";
	private static final String USER_ROLE_UPDATED = "Role_updated";
	
	@Autowired
	UserServiceImpl userServiceImpl;

	@Autowired
	PostServiceImpl postServiceImpl;
	
	
	    @Test
	    public void createUser() {        
	    	
	    	long count = userServiceImpl.count();
	    	
	        System.out.println("\n----- TEST CREATE: PRIJE CREATE IMA " + count + " USERA -----");
	        for (User userBefore : userServiceImpl.getAll()) {
	        	System.out.println(userBefore.toString());
			}
	        	        
	        userServiceImpl.save(NEW_USER);
	        
	        System.out.println("\n----- TEST CREATE: POSLIJE CREATE IMA " + userServiceImpl.count() + " USERA -----");
	        for (User userAfter : userServiceImpl.getAll()) {
	        	System.out.println(userAfter.toString());				
			}
	        System.out.println("\n");
	        Assert.assertTrue("Should be increased by 1", userServiceImpl.count() == count +1);   
	    }
	
	    
	    @Test
	    public void getAllUsers() {        
	    	
	    	List<User> users = userServiceImpl.getAll();
	    	
	        System.out.println("\n----- TEST READ: USERI TRENUTNO U BAZI -----");
	        for (User user : users) {
	        	System.out.println(user.toString());
			}
	        Assert.assertTrue("Should be null if not empty", users != null);        
	    }
	    
	    @Test
	    public void updateName() {
	    	
	        User user = userServiceImpl.getUser(USER_ID);
	        User userUpdated = userServiceImpl.updateName(user.getId(), USER_NAME_UPDATED);
	        
	        System.out.println("\n----- TEST UPDATE NAME: STANJE PRIJE UPDATE -----");
	        System.out.println(user.toString());
	        System.out.println("----- TEST UPDATE NAME: STANJE NAKON UPDATE -----");
	        System.out.println(userUpdated.toString());

	        Assert.assertTrue("Should be true if name was updated", user.getName() != userUpdated.getName());

	    }
	    
	    @Test
	    public void updateSurname() {
	    	
	        User user = userServiceImpl.getUser(USER_ID);
	        User userUpdated = userServiceImpl.updateSurname(user.getId(), USER_SURNAME_UPDATED);
	        
	        System.out.println("\n----- TEST UPDATE SURNAME: STANJE PRIJE UPDATE -----");
	        System.out.println(user.toString());
	        System.out.println("----- TEST UPDATE SURNAME: STANJE NAKON UPDATE -----");
	        System.out.println(userUpdated.toString());

	        Assert.assertTrue("Should be true if surname was updated", user.getSurname() != userUpdated.getSurname());

	    }
	    
	    @Test
	    @Transactional
	    public void updateUsername() {
	    	
	        User user = userServiceImpl.getUser(USER_ID);
	        User userUpdated = userServiceImpl.getUser(USER_ID);
	    	
	        System.out.println("\n----- TEST UPDATE USERNAME: STANJE PRIJE UPDATE -----");
	        System.out.println(user.toString());
	    	
	        userServiceImpl.updateUsername(POST_ID, USER_USERNAME_UPDATED);
	        userUpdated.setUsername(USER_USERNAME_UPDATED);
	        
	        System.out.println("----- TEST UPDATE USERNAME: STANJE NAKON UPDATE -----");
	        System.out.println(user.toString());

	        Assert.assertTrue("Should be true if username was updated", userUpdated.getUsername() == USER_USERNAME_UPDATED);

	    }
	    
	    @Test
	    public void updatePassword() {
	    	
	        User user = userServiceImpl.getUser(USER_ID);
	        User userUpdated = userServiceImpl.updatePassword(user.getId(), USER_PASSWORD_UPDATED);
	        
	        System.out.println("\n----- TEST UPDATE PASSWORD: STANJE PRIJE UPDATE -----");
	        System.out.println(user.toString());
	        System.out.println("----- TEST UPDATE PASSWORD: STANJE NAKON UPDATE -----");
	        System.out.println(userUpdated.toString());

	        Assert.assertTrue("Should be true if password was updated", user.getPassword() != userUpdated.getPassword());
	    }
	    
	    @Test
	    public void updateRole() {
	    	
	        User user = userServiceImpl.getUser(USER_ID);
	        User userUpdated = userServiceImpl.updateRole(user.getId(), USER_ROLE_UPDATED);
	        
	        System.out.println("\n----- TEST UPDATE ROLE: STANJE PRIJE UPDATE -----");
	        System.out.println(user.toString());
	        System.out.println("----- TEST UPDATE ROLE: STANJE NAKON UPDATE -----");
	        System.out.println(userUpdated.toString());

	        Assert.assertTrue("Should be true if role was updated", user.getRole() != userUpdated.getRole());
	    }
	    
	    @Test
	    @Transactional
	    public void deleteUser() {        
	    	
	    	Long noOfUsersBefore = userServiceImpl.count();
	    	
	        System.out.println("\n----- TEST DELETE: PRIJE DELETE IMA " + noOfUsersBefore + " USERA -----");
	        for (User user : userServiceImpl.getAll()) {
	        	System.out.println(user.toString());
			}
	        	        
	        Post post = postServiceImpl.getPost(POST_ID);
	        post.setUser(null);
	        userServiceImpl.deleteUser(USER_ID);
	        
	        Long noOfUsersAfter = userServiceImpl.count();
	        
	        System.out.println("\n----- TEST DELETE: POSLIJE DELETE IMA " + noOfUsersAfter + " USERA -----");
	        for (User userAfter : userServiceImpl.getAll()) {
	        	System.out.println(userAfter.toString());				
			}
	        Assert.assertTrue("Should be decreased by 1", noOfUsersAfter == noOfUsersBefore -1);   
	    }
}
