package com.mario.Brajko_V1.service;

import java.util.List;

import com.mario.Brajko_V1.model.Menu;

public interface MenuService {

	List<Menu> getAll();

	Menu save(Menu entity);

	long count();

	Menu getMenu(Long id);

	Menu updateTitle(Long id, String newTitle);
}