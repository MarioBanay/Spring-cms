package com.mario.Brajko_V1.service;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.mario.Brajko_V1.db.SubcategoryRepository;
import com.mario.Brajko_V1.model.Subcategory;

@Service
public class SubcategoryServiceImpl implements SubcategoryService {
	
	@Resource
	SubcategoryRepository subcategoryRepository;

	public SubcategoryServiceImpl(SubcategoryRepository subcategoryRepository) {
		this.subcategoryRepository = subcategoryRepository;
	}

	@Override
	@Transactional
	public List<Subcategory> getAll() {
		return subcategoryRepository.findAll();
	}

	@Override
	@Transactional
	public Subcategory save(Subcategory entity) {
		return subcategoryRepository.save(entity);
	}

	@Override
	@Transactional
	public long count() {
		return subcategoryRepository.count();
	}

	@Override
	@Transactional
	public Subcategory getSubcategory(Long id) {
		return subcategoryRepository.getOne(id);
	}

	@Override
	@Transactional
	public Subcategory updateTitle(Long id, String newTitle) {
		Subcategory subcategory = subcategoryRepository.getOne(id);
		subcategory.setTitle(newTitle);
		return subcategory;
	}

}
