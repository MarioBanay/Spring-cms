package com.mario.Brajko_V1.db;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mario.Brajko_V1.model.User;

public interface UserRepository extends JpaRepository<User, Long> {

}
