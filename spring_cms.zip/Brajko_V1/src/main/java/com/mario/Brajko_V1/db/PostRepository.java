package com.mario.Brajko_V1.db;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mario.Brajko_V1.model.Post;

public interface PostRepository extends JpaRepository<Post, Long> {

}
