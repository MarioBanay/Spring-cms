package com.mario.Brajko_V1.service;

import java.util.List;

import com.mario.Brajko_V1.model.Category;

public interface CategoryService {

	List<Category> getAll();

	Category save(Category entity);

	long count();

	Category getCategory(Long id);

	Category updateTitle(Long id, String newTitle);

}