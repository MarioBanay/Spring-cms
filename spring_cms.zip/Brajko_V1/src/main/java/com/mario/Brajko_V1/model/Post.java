package com.mario.Brajko_V1.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Proxy;

@Entity
@Proxy(lazy = false)
public class Post implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2307876834058548539L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column
	private String title;
	
	@Column
	private String content;
	
	@ManyToOne
	@JoinColumn(referencedColumnName="username")
	private User user;
	
	@ManyToOne
	@JoinColumn(referencedColumnName="title")
	private Menu menu;
	
	@ManyToOne
	@JoinColumn(referencedColumnName="title")
	private Category category;
	
	@ManyToOne
	@JoinColumn(referencedColumnName="title")
	private Subcategory subcategory;

	public Post() {
	}

	public Post(String title, String content, User user, Menu menu, Category category, Subcategory subcategory) {
		this.title = title;
		this.content = content;
		this.user = user;
		this.menu = menu;
		this.category = category;
		this.subcategory = subcategory;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Subcategory getSubcategory() {
		return subcategory;
	}

	public void setSubcategory(Subcategory subcategory) {
		this.subcategory = subcategory;
	}

	@Override
	public String toString() {
		return "Post [id=" + id + ", title=" + title + ", content=" + content + ", user=" + user + ", menu=" + menu
				+ ", category=" + category + ", subcategory=" + subcategory + "]";
	}
}
