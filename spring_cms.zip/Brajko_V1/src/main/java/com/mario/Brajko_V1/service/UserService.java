package com.mario.Brajko_V1.service;

import java.util.List;

import com.mario.Brajko_V1.model.User;

public interface UserService {

	List<User> getAll();

	User save(User entity);

	long count();

	User getUser(Long id);

	User updateName(Long id, String newName);

	User updateSurname(Long id, String newSurname);

	User updateUsername(Long id, String newUsername);

	User updatePassword(Long id, String newPassword);
	
	User updateRole(Long id, String newRole);
	
	void deleteUser(Long id);

}