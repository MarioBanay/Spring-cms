package com.mario.Brajko_V1.service;

import java.util.List;
import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.mario.Brajko_V1.db.PostRepository;
import com.mario.Brajko_V1.model.Category;
import com.mario.Brajko_V1.model.Menu;
import com.mario.Brajko_V1.model.Post;
import com.mario.Brajko_V1.model.Subcategory;
import com.mario.Brajko_V1.model.User;

@Service
public class PostServiceImpl implements PostService {
	
	@Resource
	PostRepository postRepository;
		

	public PostServiceImpl(PostRepository postRepository) {
		this.postRepository = postRepository;
	}

	@Override
	@Transactional
	public List<Post> getAll(){
		return postRepository.findAll();
	}
	
	@Override
	@Transactional
	public Post save(Post entity) {
		return postRepository.save(entity);
	}
	
	@Override
	@Transactional
	public long count() {
		return postRepository.count();

	}
	
	@Override
	@Transactional
	public Post getPost(Long id) {
		return postRepository.getOne(id);
	}
	
	@Override
	@Transactional
	public Post updateTitle(Long id, String newTitle) {
		Post post = postRepository.getOne(id);
		post.setTitle(newTitle);
		return post;
	}
	
	@Override
	@Transactional
	public Post updateContent(Long id, String newContent) {
		Post post = postRepository.getOne(id);
		post.setContent(newContent);
		return post;
	}
	
	@Override
	@Transactional
	public Post updateAuthor(Long id, User newUser) {
		Post post = postRepository.getOne(id);
		post.setUser(newUser);
		return post;
	}
	
	@Override
	@Transactional
	public Post updateMenu(Long id, Menu newMenu) {
		Post post = postRepository.getOne(id);
		post.setMenu(newMenu);
		return post;
	}
	
	@Override
	@Transactional
	public Post updateCategory(Long id, Category newCategory) {
		Post post = postRepository.getOne(id);
		post.setCategory(newCategory);
		return post;
	}
	@Override
	@Transactional
	public Post updateSubcategory(Long id, Subcategory newSubcategory) {
		Post post = postRepository.getOne(id);
		post.setSubcategory(newSubcategory);
		return post;
	}
}
