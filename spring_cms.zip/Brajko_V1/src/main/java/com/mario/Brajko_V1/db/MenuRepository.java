package com.mario.Brajko_V1.db;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mario.Brajko_V1.model.Menu;

public interface MenuRepository extends JpaRepository<Menu, Long> {

}
