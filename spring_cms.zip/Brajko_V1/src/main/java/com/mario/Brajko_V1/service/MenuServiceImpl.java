package com.mario.Brajko_V1.service;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.mario.Brajko_V1.db.MenuRepository;
import com.mario.Brajko_V1.model.Menu;

@Service
public class MenuServiceImpl implements MenuService {
	
	@Resource
	MenuRepository menuRepository;

	public MenuServiceImpl(MenuRepository menuRepository) {
		this.menuRepository = menuRepository;
	}

	@Override
	@Transactional
	public List<Menu> getAll() {
		return menuRepository.findAll();
	}

	@Override
	@Transactional
	public Menu save(Menu entity) {
		return menuRepository.save(entity);
	}

	@Override
	@Transactional
	public long count() {
		return menuRepository.count();
	}

	@Override
	@Transactional
	public Menu getMenu(Long id) {
		return menuRepository.getOne(id);
	}

	@Override
	@Transactional
	public Menu updateTitle(Long id, String newTitle) {
		Menu menu = menuRepository.getOne(id);
		menu.setTitle(newTitle);
		return menu;
	}

}
