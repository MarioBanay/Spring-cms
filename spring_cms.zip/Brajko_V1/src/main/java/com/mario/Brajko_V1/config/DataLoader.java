package com.mario.Brajko_V1.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.mario.Brajko_V1.model.Category;
import com.mario.Brajko_V1.model.Menu;
import com.mario.Brajko_V1.model.Post;
import com.mario.Brajko_V1.model.Subcategory;
import com.mario.Brajko_V1.model.User;
import com.mario.Brajko_V1.service.CategoryServiceImpl;
import com.mario.Brajko_V1.service.MenuServiceImpl;
import com.mario.Brajko_V1.service.PostServiceImpl;
import com.mario.Brajko_V1.service.SubcategoryServiceImpl;
import com.mario.Brajko_V1.service.UserServiceImpl;

@Component
public class DataLoader implements ApplicationRunner {
	
	@Autowired
	MenuServiceImpl menuServiceImpl;
	
	@Autowired
	UserServiceImpl userServiceImpl;
	
	@Autowired
	CategoryServiceImpl categoryServiceImpl;
	
	@Autowired
	SubcategoryServiceImpl subcategoryServiceImpl;
	
	@Autowired
	PostServiceImpl postServiceImpl;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		
		// POPULATING DATABASE
	
		User mslavkic = new User("Mirko","Slavkic","mslavkic","passwordms","ROLE_USER");
		User smirkic = new User("Slavko","Mirkic","smirkic","passwordsm", "ROLE_USER");
		User pperic = new User("Pero","Peric","pperic","passwordpp", "ROLE_ADMIN");
		
		
		Menu testMenu = new Menu("Test menu");
		Menu testMenu2 = new Menu("Test menu 2");
		
		
		Category znanost = new Category("Znanost", testMenu);
		Category biznis = new Category("Biznis", testMenu);
		
		Subcategory medicina = new Subcategory("Medicina", znanost);
		Subcategory racunarstvo = new Subcategory("Racunarstvo", znanost);
		
		Post post1 = new Post("Otkriven lijek za lijenost", "Potvrđeno je da je počela proizvodnja revolucionarnog lijeka za lijenost.", mslavkic, testMenu, znanost, medicina);
		Post post2 = new Post("Obogatio sam se na Bitcoinu", "Ako kupite moju novu pdf knjigu, moći ćete si kupiti Ferrari za godinu dana.", smirkic, testMenu, znanost, racunarstvo);

			
		userServiceImpl.save(mslavkic);
		userServiceImpl.save(smirkic);	
		userServiceImpl.save(pperic);	
		
		menuServiceImpl.save(testMenu);
		menuServiceImpl.save(testMenu2);

		categoryServiceImpl.save(znanost);
		categoryServiceImpl.save(biznis);
		
		subcategoryServiceImpl.save(medicina);
		subcategoryServiceImpl.save(racunarstvo);
		
		postServiceImpl.save(post1);
		postServiceImpl.save(post2);		
	}
}
