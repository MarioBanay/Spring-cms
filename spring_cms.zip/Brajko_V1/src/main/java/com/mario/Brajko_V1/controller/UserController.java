package com.mario.Brajko_V1.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mario.Brajko_V1.model.User;
import com.mario.Brajko_V1.service.UserService;
import com.mario.Brajko_V1.service.UserServiceImpl;

@Controller
public class UserController {

	@Autowired
	UserServiceImpl userServiceImpl;
	
	@GetMapping("/home")
	public String home(Model model) {
		
		List<User> users = new ArrayList<>();
		users = userServiceImpl.getAll();
		
		model.addAttribute("users", users);
		
		return "home";
	}
	
    @RequestMapping(value="/editUser", method = RequestMethod.POST)
    public String editUser(ModelMap model, @RequestParam Long id) {  
    	
    	User user = userServiceImpl.getUser(id);
    	
    	System.out.println("----- Ispis odavde: " + id.toString());
        model.addAttribute("user", user);
        return "editUser";
    }
    
    @RequestMapping(value="/deleteUser", method = RequestMethod.POST)
    public String deleteUser(ModelMap model, @RequestParam Long id) {  
    	
    	User user = userServiceImpl.getUser(id);
    	
    	userServiceImpl.deleteUser(id);
    	
        // do something with name & password
    	System.out.println("----- Ispis from deleteUser: " + user.toString());
        model.addAttribute("user", user);
        return "redirect:home";
    }
    
	@RequestMapping(value="/createUser", method = RequestMethod.POST)
	public String createUser(ModelMap model) {

		//System.out.println("----- NOVI USER: " + user);
				
		return "createUser";
	}
}
