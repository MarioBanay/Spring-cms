package com.mario.Brajko_V1.service;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.mario.Brajko_V1.db.CategoryRepository;
import com.mario.Brajko_V1.model.Category;

@Service
public class CategoryServiceImpl implements CategoryService {
	
	@Resource
	CategoryRepository categoryRepository;

	public CategoryServiceImpl(CategoryRepository categoryRepository) {
		this.categoryRepository = categoryRepository;
	}

	@Override
	@Transactional
	public List<Category> getAll() {
		return categoryRepository.findAll();
	}

	@Override
	@Transactional
	public Category save(Category entity) {
		return categoryRepository.save(entity);
	}

	@Override
	@Transactional
	public long count() {
		return categoryRepository.count();
	}

	@Override
	@Transactional
	public Category getCategory(Long id) {
		return categoryRepository.getOne(id);
	}

	@Override
	@Transactional
	public Category updateTitle(Long id, String newTitle) {
		Category category = categoryRepository.getOne(id);
		category.setTitle(newTitle);
		return category;
	}

}
