package com.mario.Brajko_V1.service;

import java.util.List;

import com.mario.Brajko_V1.model.Category;
import com.mario.Brajko_V1.model.Menu;
import com.mario.Brajko_V1.model.Post;
import com.mario.Brajko_V1.model.Subcategory;
import com.mario.Brajko_V1.model.User;

public interface PostService {

	List<Post> getAll();

	Post save(Post entity);

	long count();

	Post getPost(Long id);

	Post updateTitle(Long id, String newTitle);

	Post updateContent(Long id, String newContent);

	Post updateAuthor(Long id, User newAuthor);

	Post updateMenu(Long id, Menu newMenu);

	Post updateCategory(Long id, Category newCategory);

	Post updateSubcategory(Long id, Subcategory newSubcategory);

}