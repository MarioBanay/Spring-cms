package com.mario.Brajko_V1.service;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.mario.Brajko_V1.db.UserRepository;
import com.mario.Brajko_V1.model.User;

@Service
public class UserServiceImpl implements UserService {
	
	@Resource
	UserRepository userRepository;

	public UserServiceImpl(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@Override
	@Transactional
	public List<User> getAll(){
		return userRepository.findAll();
	}
	
	@Override
	@Transactional
	public User save(User entity) {
		return userRepository.save(entity);
	}
	
	@Override
	@Transactional
	public long count() {
		return userRepository.count();

	}
	
	@Override
	@Transactional
	public User getUser(Long id) {
		return userRepository.getOne(id);
	}
	
	@Override
	@Transactional
	public User updateName(Long id, String newName) {
		User user = userRepository.getOne(id);
		user.setName(newName);
		return user;
	}
	
	@Override
	@Transactional
	public User updateSurname(Long id, String newSurname) {
		User user = userRepository.getOne(id);
		user.setSurname(newSurname);
		return user;
	}
	
	@Override
	@Transactional
	public User updateUsername(Long id, String newUsername) {

		User user = userRepository.getOne(id);
		user.setUsername(newUsername);
		
		return user;
	}
	
	@Override
	@Transactional
	public User updatePassword(Long id, String newPassword) {
		User user = userRepository.getOne(id);
		user.setPassword(newPassword);
		return user;
	}

	@Override
	public User updateRole(Long id, String newRole) {
		User user = userRepository.getOne(id);
		user.setRole(newRole);
		return user;
	}

	@Override
	public void deleteUser(Long id) {
		userRepository.deleteById(id);
	}
	
	
}
