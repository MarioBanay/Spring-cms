package com.mario.Brajko_V1.service;

import java.util.List;

import com.mario.Brajko_V1.model.Subcategory;

public interface SubcategoryService {

	List<Subcategory> getAll();

	Subcategory save(Subcategory entity);

	long count();

	Subcategory getSubcategory(Long id);

	Subcategory updateTitle(Long id, String newTitle);

}